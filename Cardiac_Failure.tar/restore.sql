--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Cardiac_Failure";
--
-- Name: Cardiac_Failure; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Cardiac_Failure" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "Cardiac_Failure" OWNER TO postgres;

\connect "Cardiac_Failure"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cardiaccomplications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cardiaccomplications (
    inpatient_number bigint,
    nyha_cardiac_function_classification bigint,
    killip_grade bigint,
    myocardial_infarction bigint,
    congestive_heart_failure bigint,
    peripheral_vascular_disease bigint,
    type_of_heart_failure text,
    lvef double precision,
    left_ventricular_end_diastolic_diameter_lv double precision,
    mitral_valve_ems double precision,
    mitral_valve_ams double precision,
    ea double precision,
    tricuspid_valve_return_velocity double precision,
    tricuspid_valve_return_pressure double precision
);


ALTER TABLE public.cardiaccomplications OWNER TO postgres;

--
-- Name: demography; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.demography (
    inpatient_number bigint NOT NULL,
    gender text,
    weight double precision,
    height double precision,
    bmi double precision,
    occupation text,
    agecat text
);


ALTER TABLE public.demography OWNER TO postgres;

--
-- Name: hospitalization_discharge; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hospitalization_discharge (
    inpatient_number bigint,
    destinationdischarge text,
    admission_ward text,
    admission_way text,
    discharge_department text,
    visit_times bigint,
    respiratory_support text,
    oxygen_inhalation text,
    dischargeday bigint,
    admission_date timestamp without time zone,
    outcome_during_hospitalization text,
    death_within_28_days bigint,
    re_admission_within_28_days bigint,
    death_within_3_months bigint,
    re_admission_within_3_months bigint,
    death_within_6_months bigint,
    re_admission_within_6_months bigint,
    time_of_death__days_from_admission double precision,
    readmission_time_days_from_admission double precision,
    return_to_emergency_department_within_6_months double precision,
    time_to_emergency_department_within_6_months double precision
);


ALTER TABLE public.hospitalization_discharge OWNER TO postgres;

--
-- Name: labs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.labs (
    inpatient_number bigint,
    body_temperature double precision,
    pulse bigint,
    respiration bigint,
    systolic_blood_pressure bigint,
    diastolic_blood_pressure bigint,
    map_value double precision,
    fio2 bigint,
    creatinine_enzymatic_method double precision,
    urea double precision,
    uric_acid double precision,
    glomerular_filtration_rate double precision,
    cystatin double precision,
    white_blood_cell double precision,
    monocyte_ratio double precision,
    monocyte_count double precision,
    red_blood_cell double precision,
    coefficient_of_variation_of_red_blood_cell_distribution_width double precision,
    standard_deviation_of_red_blood_cell_distribution_width double precision,
    mean_corpuscular_volume double precision,
    hematocrit double precision,
    lymphocyte_count double precision,
    mean_hemoglobin_volume double precision,
    mean_hemoglobin_concentration double precision,
    mean_platelet_volume double precision,
    basophil_ratio double precision,
    basophil_count double precision,
    eosinophil_ratio double precision,
    eosinophil_count double precision,
    hemoglobin double precision,
    platelet double precision,
    platelet_distribution_width double precision,
    platelet_hematocrit double precision,
    neutrophil_ratio double precision,
    neutrophil_count double precision,
    d_dimer double precision,
    international_normalized_ratio double precision,
    activated_partial_thromboplastin_time double precision,
    thrombin_time double precision,
    prothrombin_activity double precision,
    prothrombin_time_ratio double precision,
    fibrinogen double precision,
    high_sensitivity_troponin double precision,
    myoglobin double precision,
    carbon_dioxide_binding_capacity double precision,
    calcium double precision,
    potassium double precision,
    chloride double precision,
    sodium double precision,
    inorganic_phosphorus double precision,
    serum_magnesium double precision,
    creatine_kinase_isoenzyme_to_creatine_kinase double precision,
    hydroxybutyrate_dehydrogenase_to_lactate_dehydrogenase double precision,
    hydroxybutyrate_dehydrogenase double precision,
    glutamic_oxaloacetic_transaminase double precision,
    creatine_kinase double precision,
    creatine_kinase_isoenzyme double precision,
    lactate_dehydrogenase double precision,
    brain_natriuretic_peptide double precision,
    high_sensitivity_protein double precision,
    nucleotidase double precision,
    fucosidase double precision,
    albumin double precision,
    white_globulin_ratio double precision,
    cholinesterase double precision,
    glutamyltranspeptidase double precision,
    glutamic_pyruvic_transaminase double precision,
    glutamic_oxaliplatin double precision,
    indirect_bilirubin double precision,
    alkaline_phosphatase double precision,
    globulin double precision,
    direct_bilirubin double precision,
    total_bilirubin double precision,
    total_bile_acid double precision,
    total_protein double precision,
    erythrocyte_sedimentation_rate double precision,
    cholesterol double precision,
    low_density_lipoprotein_cholesterol double precision,
    triglyceride double precision,
    high_density_lipoprotein_cholesterol double precision,
    homocysteine double precision,
    apolipoprotein_a double precision,
    apolipoprotein_b double precision,
    lipoprotein double precision,
    ph double precision,
    standard_residual_base double precision,
    standard_bicarbonate double precision,
    partial_pressure_of_carbon_dioxide double precision,
    total_carbon_dioxide double precision,
    methemoglobin double precision,
    hematocrit_blood_gas double precision,
    reduced_hemoglobin double precision,
    potassium_ion double precision,
    chloride_ion double precision,
    sodium_ion double precision,
    glucose_blood_gas double precision,
    lactate double precision,
    measured_residual_base double precision,
    measured_bicarbonate double precision,
    carboxyhemoglobin double precision,
    body_temperature_blood_gas double precision,
    oxygen_saturation double precision,
    partial_oxygen_pressure double precision,
    oxyhemoglobin double precision,
    anion_gap double precision,
    free_calcium double precision,
    total_hemoglobin double precision
);


ALTER TABLE public.labs OWNER TO postgres;

--
-- Name: patient_precriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_precriptions (
    inpatient_number bigint,
    drug_name text
);


ALTER TABLE public.patient_precriptions OWNER TO postgres;

--
-- Name: patienthistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patienthistory (
    inpatient_number bigint,
    cerebrovascular_disease bigint,
    dementia bigint,
    chronic_obstructive_pulmonary_disease bigint,
    connective_tissue_disease bigint,
    peptic_ulcer_disease double precision,
    diabetes bigint,
    moderate_to_severe_chronic_kidney_disease double precision,
    hemiplegia bigint,
    leukemia bigint,
    malignant_lymphoma bigint,
    solid_tumor bigint,
    liver_disease double precision,
    aids bigint,
    cci_score double precision,
    type_ii_respiratory_failure text,
    acute_renal_failure bigint
);


ALTER TABLE public.patienthistory OWNER TO postgres;

--
-- Name: responsivenes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.responsivenes (
    inpatient_number bigint NOT NULL,
    eye_opening bigint,
    verbal_response bigint,
    movement bigint,
    consciousness text,
    gcs bigint
);


ALTER TABLE public.responsivenes OWNER TO postgres;

--
-- Data for Name: cardiaccomplications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cardiaccomplications (inpatient_number, nyha_cardiac_function_classification, killip_grade, myocardial_infarction, congestive_heart_failure, peripheral_vascular_disease, type_of_heart_failure, lvef, left_ventricular_end_diastolic_diameter_lv, mitral_valve_ems, mitral_valve_ams, ea, tricuspid_valve_return_velocity, tricuspid_valve_return_pressure) FROM stdin;
\.
COPY public.cardiaccomplications (inpatient_number, nyha_cardiac_function_classification, killip_grade, myocardial_infarction, congestive_heart_failure, peripheral_vascular_disease, type_of_heart_failure, lvef, left_ventricular_end_diastolic_diameter_lv, mitral_valve_ems, mitral_valve_ams, ea, tricuspid_valve_return_velocity, tricuspid_valve_return_pressure) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: demography; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.demography (inpatient_number, gender, weight, height, bmi, occupation, agecat) FROM stdin;
\.
COPY public.demography (inpatient_number, gender, weight, height, bmi, occupation, agecat) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: hospitalization_discharge; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hospitalization_discharge (inpatient_number, destinationdischarge, admission_ward, admission_way, discharge_department, visit_times, respiratory_support, oxygen_inhalation, dischargeday, admission_date, outcome_during_hospitalization, death_within_28_days, re_admission_within_28_days, death_within_3_months, re_admission_within_3_months, death_within_6_months, re_admission_within_6_months, time_of_death__days_from_admission, readmission_time_days_from_admission, return_to_emergency_department_within_6_months, time_to_emergency_department_within_6_months) FROM stdin;
\.
COPY public.hospitalization_discharge (inpatient_number, destinationdischarge, admission_ward, admission_way, discharge_department, visit_times, respiratory_support, oxygen_inhalation, dischargeday, admission_date, outcome_during_hospitalization, death_within_28_days, re_admission_within_28_days, death_within_3_months, re_admission_within_3_months, death_within_6_months, re_admission_within_6_months, time_of_death__days_from_admission, readmission_time_days_from_admission, return_to_emergency_department_within_6_months, time_to_emergency_department_within_6_months) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: labs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.labs (inpatient_number, body_temperature, pulse, respiration, systolic_blood_pressure, diastolic_blood_pressure, map_value, fio2, creatinine_enzymatic_method, urea, uric_acid, glomerular_filtration_rate, cystatin, white_blood_cell, monocyte_ratio, monocyte_count, red_blood_cell, coefficient_of_variation_of_red_blood_cell_distribution_width, standard_deviation_of_red_blood_cell_distribution_width, mean_corpuscular_volume, hematocrit, lymphocyte_count, mean_hemoglobin_volume, mean_hemoglobin_concentration, mean_platelet_volume, basophil_ratio, basophil_count, eosinophil_ratio, eosinophil_count, hemoglobin, platelet, platelet_distribution_width, platelet_hematocrit, neutrophil_ratio, neutrophil_count, d_dimer, international_normalized_ratio, activated_partial_thromboplastin_time, thrombin_time, prothrombin_activity, prothrombin_time_ratio, fibrinogen, high_sensitivity_troponin, myoglobin, carbon_dioxide_binding_capacity, calcium, potassium, chloride, sodium, inorganic_phosphorus, serum_magnesium, creatine_kinase_isoenzyme_to_creatine_kinase, hydroxybutyrate_dehydrogenase_to_lactate_dehydrogenase, hydroxybutyrate_dehydrogenase, glutamic_oxaloacetic_transaminase, creatine_kinase, creatine_kinase_isoenzyme, lactate_dehydrogenase, brain_natriuretic_peptide, high_sensitivity_protein, nucleotidase, fucosidase, albumin, white_globulin_ratio, cholinesterase, glutamyltranspeptidase, glutamic_pyruvic_transaminase, glutamic_oxaliplatin, indirect_bilirubin, alkaline_phosphatase, globulin, direct_bilirubin, total_bilirubin, total_bile_acid, total_protein, erythrocyte_sedimentation_rate, cholesterol, low_density_lipoprotein_cholesterol, triglyceride, high_density_lipoprotein_cholesterol, homocysteine, apolipoprotein_a, apolipoprotein_b, lipoprotein, ph, standard_residual_base, standard_bicarbonate, partial_pressure_of_carbon_dioxide, total_carbon_dioxide, methemoglobin, hematocrit_blood_gas, reduced_hemoglobin, potassium_ion, chloride_ion, sodium_ion, glucose_blood_gas, lactate, measured_residual_base, measured_bicarbonate, carboxyhemoglobin, body_temperature_blood_gas, oxygen_saturation, partial_oxygen_pressure, oxyhemoglobin, anion_gap, free_calcium, total_hemoglobin) FROM stdin;
\.
COPY public.labs (inpatient_number, body_temperature, pulse, respiration, systolic_blood_pressure, diastolic_blood_pressure, map_value, fio2, creatinine_enzymatic_method, urea, uric_acid, glomerular_filtration_rate, cystatin, white_blood_cell, monocyte_ratio, monocyte_count, red_blood_cell, coefficient_of_variation_of_red_blood_cell_distribution_width, standard_deviation_of_red_blood_cell_distribution_width, mean_corpuscular_volume, hematocrit, lymphocyte_count, mean_hemoglobin_volume, mean_hemoglobin_concentration, mean_platelet_volume, basophil_ratio, basophil_count, eosinophil_ratio, eosinophil_count, hemoglobin, platelet, platelet_distribution_width, platelet_hematocrit, neutrophil_ratio, neutrophil_count, d_dimer, international_normalized_ratio, activated_partial_thromboplastin_time, thrombin_time, prothrombin_activity, prothrombin_time_ratio, fibrinogen, high_sensitivity_troponin, myoglobin, carbon_dioxide_binding_capacity, calcium, potassium, chloride, sodium, inorganic_phosphorus, serum_magnesium, creatine_kinase_isoenzyme_to_creatine_kinase, hydroxybutyrate_dehydrogenase_to_lactate_dehydrogenase, hydroxybutyrate_dehydrogenase, glutamic_oxaloacetic_transaminase, creatine_kinase, creatine_kinase_isoenzyme, lactate_dehydrogenase, brain_natriuretic_peptide, high_sensitivity_protein, nucleotidase, fucosidase, albumin, white_globulin_ratio, cholinesterase, glutamyltranspeptidase, glutamic_pyruvic_transaminase, glutamic_oxaliplatin, indirect_bilirubin, alkaline_phosphatase, globulin, direct_bilirubin, total_bilirubin, total_bile_acid, total_protein, erythrocyte_sedimentation_rate, cholesterol, low_density_lipoprotein_cholesterol, triglyceride, high_density_lipoprotein_cholesterol, homocysteine, apolipoprotein_a, apolipoprotein_b, lipoprotein, ph, standard_residual_base, standard_bicarbonate, partial_pressure_of_carbon_dioxide, total_carbon_dioxide, methemoglobin, hematocrit_blood_gas, reduced_hemoglobin, potassium_ion, chloride_ion, sodium_ion, glucose_blood_gas, lactate, measured_residual_base, measured_bicarbonate, carboxyhemoglobin, body_temperature_blood_gas, oxygen_saturation, partial_oxygen_pressure, oxyhemoglobin, anion_gap, free_calcium, total_hemoglobin) FROM '$$PATH$$/3349.dat';

--
-- Data for Name: patient_precriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_precriptions (inpatient_number, drug_name) FROM stdin;
\.
COPY public.patient_precriptions (inpatient_number, drug_name) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: patienthistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patienthistory (inpatient_number, cerebrovascular_disease, dementia, chronic_obstructive_pulmonary_disease, connective_tissue_disease, peptic_ulcer_disease, diabetes, moderate_to_severe_chronic_kidney_disease, hemiplegia, leukemia, malignant_lymphoma, solid_tumor, liver_disease, aids, cci_score, type_ii_respiratory_failure, acute_renal_failure) FROM stdin;
\.
COPY public.patienthistory (inpatient_number, cerebrovascular_disease, dementia, chronic_obstructive_pulmonary_disease, connective_tissue_disease, peptic_ulcer_disease, diabetes, moderate_to_severe_chronic_kidney_disease, hemiplegia, leukemia, malignant_lymphoma, solid_tumor, liver_disease, aids, cci_score, type_ii_respiratory_failure, acute_renal_failure) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: responsivenes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.responsivenes (inpatient_number, eye_opening, verbal_response, movement, consciousness, gcs) FROM stdin;
\.
COPY public.responsivenes (inpatient_number, eye_opening, verbal_response, movement, consciousness, gcs) FROM '$$PATH$$/3352.dat';

--
-- Name: demography demography_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.demography
    ADD CONSTRAINT demography_pkey PRIMARY KEY (inpatient_number);


--
-- Name: cardiaccomplications cardiaccomplications_inpatient_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cardiaccomplications
    ADD CONSTRAINT cardiaccomplications_inpatient_number_fkey FOREIGN KEY (inpatient_number) REFERENCES public.demography(inpatient_number) NOT VALID;


--
-- Name: hospitalization_discharge hospitalization_discharge_inpatient_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hospitalization_discharge
    ADD CONSTRAINT hospitalization_discharge_inpatient_number_fkey FOREIGN KEY (inpatient_number) REFERENCES public.demography(inpatient_number) NOT VALID;


--
-- Name: labs labs_inpatient_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labs
    ADD CONSTRAINT labs_inpatient_number_fkey FOREIGN KEY (inpatient_number) REFERENCES public.demography(inpatient_number) NOT VALID;


--
-- Name: patient_precriptions patient_precriptions_inpatient_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_precriptions
    ADD CONSTRAINT patient_precriptions_inpatient_number_fkey FOREIGN KEY (inpatient_number) REFERENCES public.demography(inpatient_number) NOT VALID;


--
-- Name: patienthistory patienthistory_inpatient_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patienthistory
    ADD CONSTRAINT patienthistory_inpatient_number_fkey FOREIGN KEY (inpatient_number) REFERENCES public.demography(inpatient_number) NOT VALID;


--
-- Name: responsivenes responsivenes_inpatient_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.responsivenes
    ADD CONSTRAINT responsivenes_inpatient_number_fkey FOREIGN KEY (inpatient_number) REFERENCES public.demography(inpatient_number) NOT VALID;


--
-- PostgreSQL database dump complete
--

